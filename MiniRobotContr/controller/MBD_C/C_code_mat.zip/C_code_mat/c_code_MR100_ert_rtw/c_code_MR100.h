/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: c_code_MR100.h
 *
 * Code generated for Simulink model 'c_code_MR100'.
 *
 * Model version                  : 1.2
 * Simulink Coder version         : 9.9 (R2023a) 19-Nov-2022
 * C/C++ source code generated on : Tue Sep 24 16:47:09 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: STMicroelectronics->ST10/Super10
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_c_code_MR100_h_
#define RTW_HEADER_c_code_MR100_h_
#ifndef c_code_MR100_COMMON_INCLUDES_
#define c_code_MR100_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* c_code_MR100_COMMON_INCLUDES_ */

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Forward declaration for rtModel */
typedef struct tag_RTM RT_MODEL;

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  real_T r[6];                         /* '<S1>/R1' */
  real_T l[6];                         /* '<S1>/L1' */
} DW;

/* Constant parameters (default storage) */
typedef struct {
  /* Computed Parameter: DirectLookupTablenD9_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)9'
   */
  int16_T DirectLookupTablenD9_table[201];

  /* Computed Parameter: DirectLookupTablenD1_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)1'
   */
  int16_T DirectLookupTablenD1_table[201];

  /* Computed Parameter: DirectLookupTablenD_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)'
   */
  int16_T DirectLookupTablenD_table[201];

  /* Computed Parameter: DirectLookupTablenD8_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)8'
   */
  int16_T DirectLookupTablenD8_table[201];

  /* Computed Parameter: DirectLookupTablenD7_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)7'
   */
  int16_T DirectLookupTablenD7_table[201];

  /* Computed Parameter: DirectLookupTablenD6_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)6'
   */
  int16_T DirectLookupTablenD6_table[201];

  /* Computed Parameter: DirectLookupTablenD5_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)5'
   */
  int16_T DirectLookupTablenD5_table[201];

  /* Computed Parameter: DirectLookupTablenD4_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)4'
   */
  int16_T DirectLookupTablenD4_table[201];

  /* Computed Parameter: DirectLookupTablenD3_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)3'
   */
  int16_T DirectLookupTablenD3_table[201];

  /* Computed Parameter: DirectLookupTablenD2_table
   * Referenced by: '<S2>/Direct Lookup Table (n-D)2'
   */
  int16_T DirectLookupTablenD2_table[201];

  /* Computed Parameter: DirectLookupTablenD9_table_b
   * Referenced by: '<S3>/Direct Lookup Table (n-D)9'
   */
  int16_T DirectLookupTablenD9_table_b[100];

  /* Computed Parameter: DirectLookupTablenD8_table_j
   * Referenced by: '<S3>/Direct Lookup Table (n-D)8'
   */
  int16_T DirectLookupTablenD8_table_j[100];

  /* Computed Parameter: DirectLookupTablenD_table_j
   * Referenced by: '<S3>/Direct Lookup Table (n-D)'
   */
  int16_T DirectLookupTablenD_table_j[100];

  /* Computed Parameter: DirectLookupTablenD7_table_n
   * Referenced by: '<S3>/Direct Lookup Table (n-D)7'
   */
  int16_T DirectLookupTablenD7_table_n[100];

  /* Computed Parameter: DirectLookupTablenD6_table_n
   * Referenced by: '<S3>/Direct Lookup Table (n-D)6'
   */
  int16_T DirectLookupTablenD6_table_n[100];

  /* Computed Parameter: DirectLookupTablenD5_table_k
   * Referenced by: '<S3>/Direct Lookup Table (n-D)5'
   */
  int16_T DirectLookupTablenD5_table_k[100];

  /* Computed Parameter: DirectLookupTablenD4_table_n
   * Referenced by: '<S3>/Direct Lookup Table (n-D)4'
   */
  int16_T DirectLookupTablenD4_table_n[100];

  /* Computed Parameter: DirectLookupTablenD3_table_c
   * Referenced by: '<S3>/Direct Lookup Table (n-D)3'
   */
  int16_T DirectLookupTablenD3_table_c[100];

  /* Computed Parameter: DirectLookupTablenD2_table_c
   * Referenced by: '<S3>/Direct Lookup Table (n-D)2'
   */
  int16_T DirectLookupTablenD2_table_c[100];

  /* Computed Parameter: DirectLookupTablenD1_table_m
   * Referenced by: '<S3>/Direct Lookup Table (n-D)1'
   */
  int16_T DirectLookupTablenD1_table_m[100];
} ConstP;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T R_Hip_Yaw;                    /* '<Root>/R_Hip_Yaw' */
  real_T R_Hip_Roll;                   /* '<Root>/R_Hip_Roll' */
  real_T R_Hip_Pitch;                  /* '<Root>/R_Hip_Pitch' */
  real_T R_knee;                       /* '<Root>/R_knee' */
  real_T R_Ankle_Pitch;                /* '<Root>/R_Ankle_Pitch' */
  real_T R_Ankle_Roll;                 /* '<Root>/R_Ankle_Roll' */
  real_T L_Hip_Yaw;                    /* '<Root>/L_Hip_Yaw' */
  real_T L_Hip_Roll;                   /* '<Root>/L_Hip_Roll' */
  real_T L_Hip_Pitch;                  /* '<Root>/L_Hip_Pitch' */
  real_T L_knee;                       /* '<Root>/L_knee' */
  real_T L_Ankle_Pitch;                /* '<Root>/L_Ankle_Pitch' */
  real_T L_Ankle_Roll;                 /* '<Root>/L_Ankle_Roll' */
} ExtY;

/* Real-time Model Data Structure */
struct tag_RTM {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block signals and states (default storage) */
extern DW rtDW;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY rtY;

/* Constant parameters (default storage) */
extern const ConstP rtConstP;

/* Model entry point functions */
extern void c_code_MR100_initialize(void);
extern void c_code_MR100_step(void);

/* Real-time Model object */
extern RT_MODEL *const rtM;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S1>/Gain46' : Eliminated nontunable gain of 1
 * Block '<S1>/Gain47' : Eliminated nontunable gain of 1
 * Block '<S1>/Gain48' : Eliminated nontunable gain of 1
 * Block '<S1>/Gain49' : Eliminated nontunable gain of 1
 * Block '<S1>/Gain50' : Eliminated nontunable gain of 1
 * Block '<S1>/Gain51' : Eliminated nontunable gain of 1
 * Block '<S1>/Gain53' : Eliminated nontunable gain of 1
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'c_code_MR100'
 * '<S1>'   : 'c_code_MR100/Subsystem'
 * '<S2>'   : 'c_code_MR100/Subsystem/If Action Subsystem2'
 * '<S3>'   : 'c_code_MR100/Subsystem/If Action Subsystem3'
 */
#endif                                 /* RTW_HEADER_c_code_MR100_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
